<div id="kt_header_mobile" class="kt-header-mobile  kt-header-mobile--fixed ">
  <div class="kt-header-mobile__logo">
    <a href="index.html">
      <img alt="Logo" src="<?php echo e(asset('media/logo-putih.png')); ?>" style="width: 120px;" />
    </a>
  </div>
  <div class="kt-header-mobile__toolbar">
    <button class="kt-header-mobile__toggler kt-header-mobile__toggler--left" id="kt_aside_mobile_toggler">
      <span></span>
    </button>
    <button class="kt-header-mobile__topbar-toggler" id="kt_header_mobile_topbar_toggler">
      <i class="flaticon-more"></i>
    </button>
  </div>
</div>
<?php /**PATH C:\laragon\www\Absensi-Extract-2020\resources\views/layouts/admin/headbar_mobile.blade.php ENDPATH**/ ?>