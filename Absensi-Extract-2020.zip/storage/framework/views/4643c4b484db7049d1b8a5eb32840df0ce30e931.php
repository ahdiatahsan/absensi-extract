<div class="kt-footer  kt-grid__item kt-grid kt-grid--desktop kt-grid--ver-desktop" id="kt_footer">
  <div class="kt-container  kt-container--fluid ">
    <div class="kt-footer__copyright">
      <?php echo e(date('Y')); ?>&nbsp;©&nbsp;<a href="https://www.kedai.or.id" target="_blank" class="kt-link">KeDai Computerworks</a>
    </div>
  </div>
</div>
<?php /**PATH C:\laragon\www\Absensi-Extract-2020\resources\views/layouts/admin/footer.blade.php ENDPATH**/ ?>