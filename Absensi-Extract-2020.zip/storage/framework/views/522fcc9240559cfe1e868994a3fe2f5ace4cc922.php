<head>
  <meta charset="utf-8">
  <title>Absensi Extract <?php echo e(date('Y')); ?> - <?php echo $__env->yieldContent('title'); ?></title>
  <meta name="description" content="Kunjungin Admin Panel">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700|Roboto:300,400,500,600,700"
    rel="stylesheet">
  <link href="<?php echo e(asset('plugins/global/plugins.bundle.css')); ?>" rel="stylesheet" type="text/css">
  <link href="<?php echo e(asset('css/style.bundle.css')); ?>" rel="stylesheet" type="text/css">
  <link href="<?php echo e(asset('css/skins/header/base/light.css')); ?>" rel="stylesheet" type="text/css">
  <link href="<?php echo e(asset('css/skins/header/menu/light.css')); ?>" rel="stylesheet" type="text/css">
  <link href="<?php echo e(asset('css/skins/brand/dark.css')); ?>" rel="stylesheet" type="text/css">
  <link href="<?php echo e(asset('css/skins/aside/dark.css')); ?>" rel="stylesheet" type="text/css">
  <?php echo $__env->yieldContent('page_style'); ?>
  <link rel="shortcut icon" href="<?php echo e(asset('media/logo.png')); ?>">
</head>
<?php /**PATH C:\laragon\www\Absensi-Extract-2020\resources\views/layouts/admin/header.blade.php ENDPATH**/ ?>