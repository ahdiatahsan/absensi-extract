<?php $__env->startSection('title', 'Tambah Peserta'); ?>

<?php $__env->startSection('subheader'); ?>

<h3 class="kt-subheader__title">
    Peserta
</h3>
<span class="kt-subheader__separator kt-hidden"></span>
<div class="kt-subheader__breadcrumbs">
    <a href="#" class="kt-subheader__breadcrumbs-home"><i class="flaticon2-shelter"></i></a>
    <span class="kt-subheader__breadcrumbs-separator"></span>
    <a href="" class="kt-subheader__breadcrumbs-link">
        Tambah Data Peserta </a>
    <!-- <span class="kt-subheader__breadcrumbs-link kt-subheader__breadcrumbs-link--active">Active link</span> -->
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row justify-content-center">
  <div class="col-9">
    <?php echo $__env->make('layouts.admin.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
</div>

<form action="<?php echo e(route('peserta.store')); ?>" method="POST" enctype="multipart/form-data" autocomplete="off">
  <?php echo csrf_field(); ?>
  <div class="row justify-content-center">
    <div class="col-lg-9 col-md-9 col-sm-12">
      <div class="kt-portlet">
        <div class="kt-portlet__body">

          <div class="form-group">
            <label>No. Registrasi</label>
            <input class="form-control <?php $__errorArgs = ['noreg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                name="noreg" id="noreg" value="<?php echo e(old('noreg')); ?>" placeholder="001" required autofocus>
          </div>

          <div class="form-group">
            <label>Nama Lengkap</label>
            <input class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                name="nama" id="nama" value="<?php echo e(old('nama')); ?>" placeholder="Tyler Otwell" required>
          </div>

          <div class="form-group">
            <label>Konsentrasi</label>
            <select class="form-control <?php $__errorArgs = ['konsentrasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="konsentrasi"
                name="konsentrasi" required>
                <?php $__currentLoopData = $konsentrasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $konsentrasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($konsentrasi->id); ?>">
                    <?php echo e($konsentrasi->nama); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>

        </div>

        <div class="kt-portlet__foot">
          <div class="row align-items-center">
            <div class="col-12 kt-align-center">
              <button type="submit" class="btn btn-success">
                <i class="fa fa-plus"></i>
                Tambah Data
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</form>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Absensi-Extract-2020\resources\views/peserta/create.blade.php ENDPATH**/ ?>