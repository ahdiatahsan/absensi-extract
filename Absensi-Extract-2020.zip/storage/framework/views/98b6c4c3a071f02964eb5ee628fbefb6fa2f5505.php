<script src="<?php echo e(asset('plugins/global/plugins.bundle.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/scripts.bundle.js')); ?>" type="text/javascript"></script>

<?php echo $__env->yieldContent('page_script'); ?>
<?php /**PATH C:\laragon\www\Absensi-Extract-2020\resources\views/layouts/admin/script.blade.php ENDPATH**/ ?>