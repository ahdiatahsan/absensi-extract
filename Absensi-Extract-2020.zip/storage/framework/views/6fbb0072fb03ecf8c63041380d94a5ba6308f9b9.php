<form action="<?php echo e(route('konsentrasi.destroy', $konsentrasi->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>

    <button type="submit" class="btn btn-sm btn-icon btn-icon-sm btn-elevate btn-elevate-air" title="Hapus" onclick="return confirm('Hapus data ini ?')">
        <i class="fa fa-trash text-danger"></i>
    </button>

    <a href="<?php echo e(route('konsentrasi.edit', $konsentrasi->id)); ?>" class="btn btn-sm btn-icon btn-icon-sm btn-elevate btn-elevate-air" title="Ubah">
        <i class="fa fa-edit text-warning"></i>
    </a>
</form>
<?php /**PATH C:\laragon\www\Absensi-Extract-2020\resources\views/konsentrasi/index_action.blade.php ENDPATH**/ ?>